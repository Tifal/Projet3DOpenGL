var searchData=
[
  ['changecolormarkertobeswapped',['changeColorMarkerToBeSwapped',['../class_display_window.html#a9d1baaa431863ae6cdc380d7ca628a52',1,'DisplayWindow']]],
  ['changemarkercolortobeswapped',['changeMarkerColorToBeSwapped',['../class_swap_window.html#ad178219630722b8961a7df2f0701a242',1,'SwapWindow']]],
  ['changestep',['changeStep',['../class_program_window.html#a35fee7739d0955eea5ddda6f18a105b1',1,'ProgramWindow']]],
  ['choosepointslinesformersteps',['choosePointsLinesFormerSteps',['../class_program_window.html#ac0d93ef9028768df6c9d5c3add7d4508',1,'ProgramWindow']]],
  ['configurescreen',['configureScreen',['../class_program_window.html#a02a5af0f47f2b726532fe330208341bb',1,'ProgramWindow']]],
  ['connectwidgets',['connectWidgets',['../class_program_window.html#a8272d61e23782e0bcf7762644f080be1',1,'ProgramWindow']]],
  ['coordinateswindow',['CoordinatesWindow',['../class_coordinates_window.html',1,'CoordinatesWindow'],['../class_coordinates_window.html#ac6b26a5156caec5ae37c929f09ae5d34',1,'CoordinatesWindow::CoordinatesWindow()']]]
];
